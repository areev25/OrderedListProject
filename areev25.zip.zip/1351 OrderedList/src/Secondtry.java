/*import java.io.PrintWriter;
import java.util.Scanner;

public class Secondtry {
	PrintWriter UserInput = new PrintWriter("pigs");
	Scanner Input = new Scanner(System.in);
	System.out.println("Enter file name");
	// obj-name.method()
	// writes to the file
	UserInput.println(Input.nextLine());
	
		//NEED String Userprompt = Input.nextLine();
				//System.out.println(Userprompt);
				//PrintWriter newFile = new PrintWriter(Userprompt);
				//String Continue = Input.nextLine();
	boolean CorrectFile = false;{
	do {
		try {
			if(Input.equals(UserInput)) {
				//System.out.print("File name: " + UserInput.getName() + ".txt");
				//System.out.print("Path:"+ UserInput.getAbsolutePath());
				//System.out.println(" would you like to continue?");
			System.out.println("compareable works!");
			}else
			System.out.println("The File hasn't been found");
			UserInput.close();
			Input.close();
			CorrectFile = true;
		}
		catch (Exception e) {
		// deal with the exception
		// next steps
		e.printStackTrace();
		System.out.println("what does this do");
		}
		finally {
	}
	}
	// terminate the loop if flag (userisCorrect = true)
	while (!CorrectFile);
	}}}}}
*/
