import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
* <aOrderedList class sets up the values, list and size of the list to be used when adding the cars to the list>
*
* CSC 1351 Programming Project No <1 part 1>
7
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/28>
*
*/
public class aOrderedList {
		final int SIZEINCREMENTS = 20; //size of increments for increasing ordered list
		private int listSize; //the size of the ordered list
		private int numObjects; // array oList to an array of size SIZEINCREMENTS
		private int curr; //index of current element accessed via iterator methods
		private Comparable[] oList; //the ordered list
		
		/**
		* <This method:
		* this method initializes the number of objects in the list equal to zero,  the list can store 20 items, and that the list will be holding the car values that are already formatted>
		* CSC 1351 Programming Project No <1 Part 1>
		* Section <2>
		*
		* @author <Alanna Reeves-Miller>
		* @since <3/17/24>
		*
		*/
	
public  aOrderedList (int numObjects, int listSize, int SIZEINCREMENTS ){
		this.numObjects = 0;
		this.listSize = SIZEINCREMENTS;
		oList =  new Car[SIZEINCREMENTS];
		}	

/**
* <This method:Compares the current value in the array to the index that it's on and then makes space to then add it into the list>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/

public void add(Comparable newObject) {
		
	        int startindex = 0;
	        //if the value is smaller than the total size and the current index of the object we're comparing...
	        while(startindex < size() && oList[startindex].compareTo(newObject) < 0){
	        	startindex++;
	        }
	        //making space for the new value by shifting one
	        for( int i= size(); i >= startindex; i++) {
	        	oList[i+1]= oList[i];
	        }
	        //insert the new object into the space we just made
	        oList[startindex]= newObject;
	        	
			}

/**
* <This method: calls and prints the size of the  array as well as the make, price and year values for each item in it>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/
	public  void PrintCarOutput(PrintWriter values) {
		int numberOfCars = size();// Calls the size of the method
		//prints the current size of the length in the console
	values.println("Number of Cars: "+ numberOfCars);
		 for( int i=0; i<oList.length; i++) {
			 Car car = (Car)oList[i];
				values.println("Make: "+ car.getMake());
				values.println("Year: "+  car.getYear());
				values.println("Price: "+ car.getPrice());
				}
	}
	/**
	* <This method: calls and resizes the array for the possible input values it'll have to add>
	* CSC 1351 Programming Project No <1 Part 1>
	* Section <2>
	*
	* @author <Alanna Reeves-Miller>
	* @since <3/17/24>
	*
	*/
public void newArray() {
//might have to change the new array size, but maybe not b/c the instructions say a new larger array so..
int MyArray [] = new int [listSize];
int[] newValues= Arrays.copyOf(MyArray, MyArray.length);
MyArray = newValues;
}
/**
* <This method: makes it easier to call or get the current size of the oList array>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/
public int size() {
	return oList.length;
}

/**
* <This method: calls and prints the size of the  array as well as the make, price and year values for each item in it>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/

/**
* <This method: Returns the element at the specified position in this list>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/
public  Comparable get(int index) {
	//check if the index/value even exists
	if(index<0 || index >= oList.length) {
		// this would show if Index doesn't exists
	System.out.print("the index does not exists");
}
	// if you leave the return type as integer it won't be able to compare and integer with a comparable object.
return oList[index];
}

public void Iterator(Comparable[] oList) {
	this.oList = oList;
	this.curr =0;
}
/**
* <This method:  resets the parameters of the array so the following value then becomes the first value>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/

void reset() {
curr =0;
}
/**
* <This method:  Returns the next element in the iteration and increments the iterator parameters>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/
//if there's another value find it and add to it
Comparable next() {
	if(hasNext()) {
		return oList[curr++];
	}
	return SIZEINCREMENTS;
}

/**
* <This method: Returns true if the iteration has more elements to iterate through>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/

public boolean hasNext() {
	return curr < oList.length;
	
}
/**
* <This method:Removes the last element returned by the next() method>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/

//Removes the last element returned by the next() method
void remove() {
	//if the index is great than zero
	if(curr> 0) {
		//Finds the last value
		//removes the value
		 int LastValue = oList.length -1;
		 curr --;
}
}
/**
* <This method:Boolean isEmpty()
* Returns true if the array is empty and false otherwise.>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/

boolean isEmpty() {
	//firstly keep it simple
	//check if the length or total items is zero
	if(oList.length== 0) {
	System.out.println("The Array is empty");
	//needs to return true
	return true;
	}else {
		//if not say that and return that it isn't empty
	System.out.println("The Array isn't empty");	
	return false;
	}
}
/**
* <This method:Removes the element at the specified position in this list. Remember that elements that follow the removed element must “move down” to fill the hole in the array.>
* CSC 1351 Programming Project No <1 Part 1>
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/
public void remove (int index) {
	// if the index doesn't exist of if it's larger than the total values in the list
	if(index<0 || index >= oList.length) {
		//Index doesn't exists
		return;
	}
	//now that the space is empty move the elements over 1 to make up for the empty space
	for ( int i = 0; i< oList.length-1; i++) {
		oList[i]= oList[i +1];
		
	}
	// resize the array now that we know there is one less value
	oList= Arrays.copyOf(oList,oList.length-1);
	}
}
	
