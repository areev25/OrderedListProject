import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
/**
* <Prog01_aOrderedList Class is a larger 'file" that holds all the car information, the comparison information and essentially allows there to be a space for data to be compared>
*
* CSC 1351 Programming Project No <1 Part 1>
7
* Section <2>
*
* @author <Alanna Reeves-Miller>
* @since <3/17/24>
*
*/

public class Prog01_aOrderedList {
	
	/**
	* <This method names the file and then kicks out to ask for using input, later connecting it to the debugging/exception part of user input to the method below.
	* This method also sets up the way the information about the car including year, make and price to be seen within the file>
	* CSC 1351 Programming Project No <1 Part 1>
	* Section <2>
	*
	* @author <Alanna Reeves-Miller>
	* @since <3/17/24>
	*
	*/
	public static void main(String [] args) throws FileNotFoundException
  {
	PrintWriter Inputfile = new PrintWriter("Input.txt");
	  Scanner InputScan = new Scanner(System.in);
//the scanner will start off empty
	  Scanner InputFileScanner = null;
	  // allows the code to continue running/look for an user input despite and error
	  try {
		  InputFileScanner = GetInputFile("Please enter the file name");
	  }
	  catch(FileNotFoundException e) {
		  return;
	  }
	  aOrderedList orderedList = new aOrderedList(0,0,0);
	  //starts formatting the way the data will be presented
		  while(InputFileScanner.hasNextLine()) {
			String UserInput = InputFileScanner.nextLine();
			String [] Carinfo = UserInput.split(",");
				   if(Carinfo.length == 4 && Carinfo[0].equals("A")) {
				    String make = Carinfo[1];
				     int year = Integer.parseInt(Carinfo[2]);
				     int price = Integer.parseInt(Carinfo[3]);
				     Car Car = new Car(make,year,price);
				     // after formatting it, the computer adds it to a larger unsorted list.
				     orderedList.add(Car);
			  }
  }
		//tells the user the car has been added to the "database"
  System.out.println("The car is added to the list" + orderedList);
  }
  
	/**
	* <This method:
	* Asks for the file name while ensuring the console will take in and save the input
	* Checks the name
	* If the name is incorrect, it tells the user then asking if they're like to search for the  correct file again
	* this method elimates the user error through ensuring their answer about continuing will be accepted no matter if the letter is uppercase or lowercase
	* CSC 1351 Programming Project No <1 Part 1>
	* Section <2>
	*
	* @author <Alanna Reeves-Miller>
	* @since <3/17/24>
	*
	*/
public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
 Scanner scanner = new Scanner(System.in);
 File CorrectFile;
 do {
	 //prompts the user
		 System.out.print("Enter Input filename");
		 //ensures there's a space to enter the name and the user input is saved
		 String input = scanner.next();
		//makes the input equal to boolean that can be compared to the correct name
		 CorrectFile = new File (input);
		 //begins checking the boolean
			  if(!CorrectFile.isFile()) {
				  System.out.println("File specified < " + input + " >does not exist.");
				  System.out.println("Would you like to continue? <Y/N>");
				  String ChooseFile = scanner.nextLine();
						  if(!ChooseFile.equalsIgnoreCase("Y")) {
							 throw new FileNotFoundException("File isn't fount");
						  }
						  else {
							  System.out.println("Try Again Please");
				  }
			  }else {
				  return new Scanner(CorrectFile);
	  }
 			}while(true);

}
}
