/*
 * import java.io.File;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

 

 * Alanna Reeves-Miller
 * LSU ID: 896728875
 * Lab section: 2
 
public class Prog01_aOrderedList {
	
//Main Method
	// new stuff
	
	
public static void main(String[] args) throws FileNotFoundException, IOException {
	
		//Scanner Input = new Scanner(System.in);
		//System.out.println("what's the name of the file?");
		// System.out.println(Input);
		//PrintWriter newFile = new PrintWriter(newFile);
		//String Continue = Input.nextLine();
		//return;
File UserInput = new File("turtle");
Scanner Input = new Scanner(System.in);
	System.out.println("what's the name of the file?");
	 String Userprompt = Input.nextLine();
			//System.out.println(Userprompt);
			//PrintWriter newFile = new PrintWriter(Userprompt);
			//String Continue = Input.nextLine();
	
if(UserInput.equals(Userprompt)) {
	//System.out.print("File name: " + UserInput.getName() + ".txt");
	//System.out.print("Path:"+ UserInput.getAbsolutePath());
	//System.out.println(" would you like to continue?");
System.out.println("compareable works!");
}else
System.out.println("The File hasn't been found");
}
//Input.close();
}
*/

//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collections;

/* 
 * step 3
 * ArrayList<Integer> oList =  new ArrayList <Integer>(SIZEINCREMENTS);
		
		void add(Car newCar) {
			ArrayList<Integer> oList =  new ArrayList <>();
			oList.add(numObjects);
			//System.out.print(oList);
			Collections.sort(oList);
		}
		 // String toString
		//Where does step 5?
		public void ArraysLength(){
			double[] values = new double[SIZEINCREMENTS];
			 // Fill array
			double[] newValues = Arrays.copyOf(values, values.length);
			values = newValues;
		}
	public void NewArrays(ArraysLength[]){
			return	NewArrays.length();
		}
		int size(){
		return oList.length;
		}
		 Car get(int index) {
			// arr[i]= ;
	// Car get(int index)
	//	 Returns the element at the specified position in this list
		}
		boolean isEmpty() {
		boolean isEmpty = true;
			 if(NewArrays = null) {
		//Returns true if the array is empty and false otherwise
				 
		 }
		// void remove(int index)
	//	Removes the element at the specified position in this list. Remember that elements that follow the removed element must “move down” to fill the hole in the array.
	 
		 } 
		
		 }
}}
*/
